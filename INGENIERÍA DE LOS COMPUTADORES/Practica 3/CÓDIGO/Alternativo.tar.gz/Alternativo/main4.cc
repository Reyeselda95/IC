// Tareas 1-Aplicación en OpenMP
// 2 - Salida por fichero de los resultados.
// 

#include <iostream>
#include <vector>
#include <fstream>
#include <stdlib.h>
#include <string.h>
#include <omp.h> //Libreria OpenMP
using namespace std;

//Muestra el tiempo de uso de la CPU desde el comienzo de la aplicación
void mostrarMatriz(double **matriz,int fil,int col);

double CPU_time(clock_t start)
{
	double devolver;
	devolver=(start-clock())/ (double)CLOCKS_PER_SEC;
	if(devolver<0){
	  return -1*devolver;
	}
	else{
	  return devolver;
	}
}



//computes row[i] - val for all i;
void subtract(double **d, double val, double ** dst,int fijo,int fil) {
    int i=0;
    int chunk=10;
   /*#pragma omp parallel for \
   shared(d,dst,val,chunk) private(i) \
   schedule(static,chunk)*/
    for(int i = 0; i < fil; i++) {
        dst[i][fijo]= d[i][fijo] - val;
    }
   
}


double mean(double **data,int fijo, int fil) {
    double mean = 0.0;
    int chunk=10;
    int i=0;
    /*#pragma omp parallel for   \  
    default(shared) private(i)  \
    schedule(static,chunk)      \
    reduction(+:mean) */
    
    for(i=0;i<fil;i++) {
        mean += data[i][fijo];
    }

    mean = mean/fil;
    
    return mean;
}




void traspuesta(double **m,double **t,int fil, int col){
    int chunk=10;
    for(int i=0;i<fil; i++){
      
	int j=0;
	/*#pragma omp parallel for \
	shared(m,t,chunk) private(j,i) \
	schedule(static,chunk)*/
      
	for(j=0;j<col;j++){
	      t[j][i]=m[i][j];
	}
    }
    
}

void multiplicarMatrices(double **d,double **t,double ** resul,int m, int n, int p){

  
  for (int i=0;i<m;i++){
      
      for (int j=0;j<p;j++) { 

         for (int k=0;k<n;k++){
	      resul[i][j]=resul[i][j]+d[i][k]*t[k][j];

          }       

       }
    }
}

void matrizCovarianza(double ** m,double valor,int tam){

   
       
    for(int i=0;i<tam; i++){
        
	for(int j=0;j<tam;j++){
	      m[i][j]=m[i][j]*valor;
	     
	}
    }   
}


void compute_covariance_matrix(double **d, double **dst,int fil,int col) {
  
 
    double **t1; 
    
    t1=new double *[fil];

    for(int i=0;i<fil;i++){
	t1[i]=new double [col]; 
    }
    
    
    for(int i = 0; i < col; i++) {
	  double y_bar = mean(d,i,fil);
	  
	  subtract(d, y_bar,t1,i,fil);	
	  
    } 
    
    //mostrarMatriz(t1,fil,col);

    double **t2; 
    
    t2=new double *[col];

    for(int i=0;i<col;i++){
	t2[i]=new double [fil]; 
    }

    traspuesta(t1,t2,fil,col);
    
    //mostrarMatriz(t2,col,fil);
    
    multiplicarMatrices(t2,t1,dst,col,fil,col);
     
    //mostrarMatriz(dst,col,col);
    
    double valor=(double)1/(double)fil;
    
    matrizCovarianza(dst,valor,col);
    
    //mostrarMatriz(dst,col,col);
    
    for(int i=0;i<fil;i++){
      delete [] t1[i];
    }
		
    delete [] t1;

    
    
    
    for(int i=0;i<col;i++){
      delete [] t2[i];
    }		
    delete [] t2; 
    

}


void procesarLinea(string linea,double **matriz,int contfil){
   string sb;
   size_t p1=0;
   size_t p2=linea.find(" ");
   size_t p3;
   bool terminar=false;
   int i=0;
   while(terminar==false){
      
      if(p2==string::npos){
	  terminar=true;
      }else{
	  p3=p2-p1;
	  sb=linea.substr(p1,p3);
	  //cout << sb << "|";
      
          matriz[contfil][i]=atof(sb.c_str());
	  
	  p1=p2;
	  p2=linea.find(" ",p1+1);
	  i++;
      }
      
      
   }
   
   size_t tam=linea.length();
   p3=tam-p1;
   sb=linea.substr(p1,p3);
   matriz[contfil][i]=atof(sb.c_str());
  
   //cout << sb << "|";
      
      
   //cout << endl;
   
}


void procesarCantidad(string linea, int &fil,int &col){
   string sb;
   size_t p1=0;
   size_t p2=linea.find(" ");
   size_t p3;
   double num;
 
   p3=p2-p1;
   sb=linea.substr(p1,p3);
	  //cout << sb << "|";
      
   fil=atoi(sb.c_str());
   
   p1=p2;
   
   size_t tam=linea.length();
   p3=tam-p1;
   sb=linea.substr(p1,p3);
   col=atoi(sb.c_str());
   
   
  
}

//Lee las matrices que le pasas por parametro
void readMatrices(string nombre_fichero)
{
	int num_matriz = 0;
	string linea;
	ifstream file(nombre_fichero.c_str());
      
	if(file.is_open())
	{
	        getline( file,linea);
		double **matriz;
		int fil=0;
		int col=0;
		procesarCantidad(linea,fil,col);
		
		matriz=new double *[fil];
		
		for(int i=0;i<fil;i++){
		  matriz[i]=new double [col]; 
		}
		
		double **resuelta;
		resuelta=new double *[col];
    
		for(int i=0;i<col;i++){
		    resuelta[i]=new double [col]; 
		}
		
		int contfil=0;
		
		while(!file.eof() || !linea.empty())
		{
		      if(!linea.empty() && contfil<fil)
		      {
			    procesarLinea(linea,matriz,contfil);
			    contfil++;
			    
		      }else{
			    contfil=0;    
			    compute_covariance_matrix(matriz,resuelta,fil,col); 
		      }
		      
		      
		      getline( file,linea);
		}
		file.close();
		
		for(int i=0;i<fil;i++){
		   delete [] matriz[i];
		}
		delete [] matriz;
		
		for(int i=0;i<col;i++){
		    delete [] resuelta[i];
		}
		
		delete [] resuelta;
		
		
	}
	else
	{
		cout << "Problema al abrir el fichero" <<endl;
	}
}


//TODO cambiar a salida por fichero
void mostrarMatriz(double  **matriz,int fil,int col)
{
	for(unsigned int i= 0;i<fil;i++)
	{
		for(unsigned int j=0;j<col;j++)
		{
			cout << matriz[i][j] <<" ";
		}
		cout <<endl;
	}
	cout <<endl;
}

int main(int argc,const char* argv[])
{
	if(argc == 2)
	{
		
	
		clock_t start;	  

		start = clock();
		cout << "Tiempo de comienzo de la aplicacion: " <<CPU_time(start) <<endl;
		
		readMatrices(argv[1]);

		cout << "Tiempo de finalización de la aplicación: " << (double)CPU_time(start) <<endl;
	}else{
		cout << "Número de parámetros incorrecto" <<endl;
		cout << "Formato $./main nombre_de_fichero" <<endl;
		return -1;
	}
	return 0;
}
