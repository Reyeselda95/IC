//
// Cesar a ti te dejo por hacer el TODO que se encuentra en la función readMatrices, se trata de leer cada fila de la matriz y almacenarla
// según el formato que se encuentra en el fichero de ejemplo. Luego testealo y apunta cualquier problema que encuentres e intenta debuggear
// cualquier cosa que necesites ayuda me mandas un whatsapp

#include <iostream>
#include <vector>
#include <fstream>
#include <stdlib.h>
using namespace std;

//Muestra el tiempo de uso de la CPU desde el comienzo de la aplicación
double CPU_time(clock_t start)
{
	return start-clock();
}

void outer_product(vector<double> row, vector<double> col, vector<vector<double> >& dst) {
    for(unsigned i = 0; i < row.size(); i++) {
        for(unsigned j = 0; j < col.size(); i++) {
            dst[i][j] = row[i] * col[j];
        }
    }
}

//computes row[i] - val for all i;
void subtract(vector<double> row, double val, vector<double>& dst) {
    for(unsigned i = 0; i < row.size(); i++) {
        dst[i] = row[i] - val;
    }
}

//computes m[i][j] + m2[i][j]
void add(vector<vector<double> > m, vector<vector<double> > m2, vector<vector<double> >& dst) {
    for(unsigned i = 0; i < m.size(); i++) {
        for(unsigned j = 0; j < m[i].size(); j++) { 
            dst[i][j] = m[i][j] + m2[i][j];
        }
    }
}

double mean(vector<double> &data) {
    double mean = 0.0;

    for(unsigned i=0; (i < data.size());i++) {
        mean += data[i];
    }

    mean = mean/data.size();
    return mean;
}

void scale(vector<vector<double> > & d, double alpha) {
    for(unsigned i = 0; i < d.size(); i++) {
        for(unsigned j = 0; j < d[i].size(); j++) {
            d[i][j] *= alpha;
        }
    }
}

void compute_covariance_matrix(vector<vector<double> > & d, vector<vector<double> > & dst) {
    for(unsigned i = 0; i < d.size(); i++) {
        double y_bar = mean(d[i]);
        vector<double> d_d_bar(d[i].size());
        subtract(d[i], y_bar, d_d_bar);
        vector<vector<double> > t(d.size());
        outer_product(d_d_bar, d_d_bar, t);
        add(dst, t, dst);
    } 
    scale(dst, 1/(d.size() - 1));
}

//Lee las matrices que le pasas por parametro
void readMatrices(vector<vector<double> > matrix[],string nombre_fichero)
{
	int num_matriz = 0;
	string linea;
	ifstream file(nombre_fichero.c_str());

	if(file.is_open())
	{
		while( getline( file,linea))
		{
			if(linea.empty())
			{
				num_matriz++;
			}
			else
			{
				//TODO leer la linea 
			}
		}
		file.close();
	}
	else
	{
		cout << "Problema al abrir el fichero" <<endl;
	}
}

//Muestra la matriz en consola
void mostrarMatriz(vector<vector<double> > & matriz)
{
	for(unsigned int i= 0;i<matriz.size();i++)
	{
		for(unsigned int j=0;j<matriz[i].size();j++)
		{
			cout << matriz[i][j] <<" ";
		}
		cout <<endl;
	}
}

int main(int argc,const char* argv[])
{
	if(argc != 3)
	{
		cout << "Número de parámetros incorrecto" <<endl;
		cout << "Formato $./main nombre_de_fichero numero_matrices" <<endl;
		return -1;
	}
	clock_t start;
	int num_matrices = atoi(argv[2]);
	vector<vector<double> > matrices_iniciales[num_matrices];
	vector<vector<double> > matrices_resueltas[num_matrices];

	start = clock();
	cout << "Tiempo de comienzo de la aplicacion: " <<CPU_time(start) <<endl;
	readMatrices(matrices_iniciales,argv[1]);
	for(int i = 0;i<num_matrices;i++)
	{
		compute_covariance_matrix(matrices_iniciales[i],matrices_resueltas[i]);
	}
	cout << "Tiempo de finalización de la aplicación" <<CPU_time(start) <<endl;
	return 0;
}