#include "network.h"
#include <string>
#include <sstream>
#include <algorithm>
#include <iostream>
using namespace std;

int Network::read_friends(string filename) {

  ifstream db (filename.c_str());
  string line;
  users_count = -1;
  if (db.is_open()) {
    while (getline(db, line)) {

      if (users_count == -1) {
        users_count = atoi(line.c_str());
        continue;
      }

      string buffer;
      User new_user = User();
      new_user.id = atoi(line.c_str());
      getline(db, buffer);
      buffer.erase(remove(buffer.begin(), buffer.end(), '\t'), buffer.end());
      new_user.name = buffer;

      // Birth parse
      getline(db, buffer);
      new_user.birth_year = atoi(buffer.c_str());

      getline(db, buffer);
      new_user.zip_code = atoi(buffer.c_str());

      getline(db, buffer);
      // stringstream ids(buffer);
      string friend_id;
      // cout << "new user has friends ";
      for (stringstream s(buffer); s >> friend_id;) {
        new_user.friends.push_back(atoi(friend_id.c_str()));
        // cout << friend_id;
      }
      // cout << endl;
      users.push_back(new_user);
    }

  }

  return 0;

}

int Network::write_friends(string filename) {

  ofstream db (filename.c_str());
  string buffer;

  if (db.is_open()) {
    db << users_count << endl;
    for (int i = 0; i < users.size(); i++) {
      db << users[i].id << endl;
      db << "\t" << users[i].name << endl;
      db << "\t" << users[i].birth_year << endl;
      db << "\t" << users[i].zip_code << endl;
      db << "\t";
      for (int j = 0; j < users[i].friends.size(); j++) {
        db << users[i].friends[j] << " ";
      }
      db << endl;
    }
  }
  db.close();
  return 0;

}

int Network::add_user(User user) {
  user.id = users_count;
  users.push_back(user);
  users_count++;
  return 0;
}

int Network::add_connection(int id1, int id2) {
  for (int i = 0; i < users.size(); i++) {

    if (users[i].id == id1)
      users[i].add_friend(id2);

    if (users[i].id == id2)
      users[i].add_friend(id1);

  }

  return 0;
}

int Network::remove_connection(int id1, int id2) {
  for (int i = 0; i < users.size(); i++) {

    if (users[i].id == id1)
      users[i].delete_friend(id2);

    if (users[i].id == id2)
      users[i].delete_friend(id1);

  }

  return 0;
}

int Network::get_id(string username) {
  for (int i = 0; i < users.size(); i++)
    if (users[i].name == username)
      return users[i].id;

  return -1;
}
