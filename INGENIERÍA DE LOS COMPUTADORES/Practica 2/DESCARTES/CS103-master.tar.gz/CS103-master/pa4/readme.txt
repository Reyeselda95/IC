CSCI 103 Programming Assignment 4, Social Network Part 1, Fall 2014

Name: Brian Wheeler
NOTE: This assignment is using a late day!! Thanks!

Email Address: bawheele@usc.edu

NOTE: You can delete the questions, we only need your responses.

Please summarize the help you found useful for this assignment, which
may include office hours, discussion with peers, tutors, et cetera.
Saying "a CP on Tuesday" is ok if you don't remember their name.

No help used.

:

================================ Remarks ====================================

Filling in anything here is OPTIONAL.

Approximately how long did you spend on this assignment?

4:00

Were there any specific problems you encountered? This is especially useful to
know if you turned it in incomplete.

:

Do you have any other remarks?

:
