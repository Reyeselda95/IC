#ifndef NETWORK_H
#define NETWORK_H

#include "user.h"
#include <string>

class Network {
 public:
   string filename;
   vector<User> users;
   int users_count;
   int read_friends(string filename);
   int write_friends(string filename);
   int add_user(User user);
   int add_connection(int id1, int id2);
   int remove_connection(int id1, int id2);
   int get_id(string username);

   Network(string filename) {
     this->filename = filename;
   }

 private:


};


#endif
