#ifndef USER_H
#define USER_H
#include <iostream>
#include <string>
#include <vector>
#include <fstream>

using namespace std;

class User {

  public:
    int id;
    string name;
    int birth_year;
    int zip_code;
    vector<int> friends;
    int add_friend(int);
    int delete_friend(int);

    User(string name, int born, int zip_code) {
      this->zip_code = zip_code;
      this->name = name;
      this->birth_year = born;
    }

    User() {
      
    }


  private:

};


#endif
