#include "user.h"
#include <string>
using namespace std;

int User::delete_friend(int friend_id) {
  for (int i = 0; i< friends.size(); i++)
    if (friends[i] == friend_id)
      friends.erase(friends.begin() + i);

  return 0;
}

int User::add_friend(int friend_id) {

  for (int i = 0; i < this->friends.size(); i++)
    if (this->friends[i] == friend_id)
      return 0;

  this->friends.push_back(friend_id);

  return 0;
}
