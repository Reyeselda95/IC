#include "network.h"
#include "user.h"
#include <iostream>
#include <string>
#include <sstream>
#include <iterator>
#include <algorithm>

using namespace std;

void print_header() {
  cout << "ID      Name           Year      Zip" << endl;
  cout << "=======================================================" << endl;
}

void print_user(User u) {
  cout << u.id << ".     " << u.name << "            " << u.birth_year << "     " << u.zip_code << endl;
}

int main(int argc, char *argv[])
{

  if (argc != 2) {
    cout << "Usage: ./social_network database_filename";
    return 1;
  }

  string filename = argv[1];

  Network network = Network(filename);
  network.read_friends(filename);

  while (true) {
    cout << "> ";

    int option;
    cin >> option;

    switch( option ) {

      case 1:
      {
        string name, last_name;

        cin >> name;
        name.append(" ");
        cin >> last_name;
        name.append(last_name);

        int born;
        cin >> born;

        int zip;
        cin >> zip;

        User new_user = User(name, born, zip);
        network.add_user(new_user);

      }
        break;
      case 2:
      {
        // Add friend connection
        string fn, ln, fn2, ln2;
        cin >> fn;
        cin >> ln;
        cin >> fn2;
        cin >> ln2;
        int id1 = network.get_id(fn.append(" ").append(ln));
        int id2 = network.get_id(fn2.append(" ").append(ln2));
        network.add_connection(id1, id2);
        break;
      }

      case 3:
      {
        // Remove freind
        string fn, ln, fn2, ln2;
        cin >> fn;
        cin >> ln;
        cin >> fn2;
        cin >> ln2;
        int id1 = network.get_id(fn.append(" ").append(ln));
        int id2 = network.get_id(fn2.append(" ").append(ln2));
        network.remove_connection(id1, id2);
        break;
      }
      case 4:
      {
        // Output user database
        print_header();
        for (int i = 0; i < network.users.size(); i++)
          print_user(network.users[i]);
        break;
      }
      case 5:
      {
        // print users friends
        string fn, ln;
        cin >> fn;
        cin >> ln;
        int id = network.get_id(fn.append(" ").append(ln));

        for (int i = 0; i < network.users.size(); i++)
          for (int j = 0; j < network.users[i].friends.size(); j++)
            if (network.users[i].friends[j] == id)
              print_user(network.users[i]);


        break;

      }
      case 6:
      {
        // Write to file
        string filename;
        cin >> filename;
        network.write_friends(filename);
        break;
      }
      case 7:
        // exit
        return 1;
        break;
    }



  }

}
