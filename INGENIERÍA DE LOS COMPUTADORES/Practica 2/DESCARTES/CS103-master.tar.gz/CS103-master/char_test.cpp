#include <iostream>
using namespace std;

int main() {
	
	char* buffer = new char[80];
	strcpy(buffer, "Question");
	strcpy(buffer+5, "s");
	cout << buffer;

  return 0;
}
