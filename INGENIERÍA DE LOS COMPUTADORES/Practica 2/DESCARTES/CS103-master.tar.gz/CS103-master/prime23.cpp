#include <iostream>

using namespace std;

int main() {

	cout << "Enter a number: ";
	float x;
	cin >> x;
	int threes = 0; 
	int twos = 0;
	bool success = false;
	for (int i=1; i <= x; i *= 3) {
		for (int j=1; j*i <= x; j*=2) {
			if (j * i == x) {
				cout << "Threes: " << threes << endl;
				cout << "Twos: " << twos << endl;
				success = true;
			}
			twos++;
		}
		twos = 0;
		threes++;
	}

	if (!success) 
		cout << "No" << endl;

	return 0;
}
