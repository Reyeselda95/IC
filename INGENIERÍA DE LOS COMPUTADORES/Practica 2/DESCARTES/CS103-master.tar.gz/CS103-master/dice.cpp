#include <iostream>
#include <stdlib.h>
using namespace std;

int roll() {
	return rand() % 6 + 1;
}

void printHistogram(int count[]) {
	
	for (int i=0; i < 21; i++) {
		cout << i + 4 << ": ";
		for (int j=0; j<count[i]; j++) 
			cout << "X";
		cout << endl;
	}
	
}

int main() {
	srand(time(NULL));
	cout << "How many rolls would you like? ";
	int rolls;
	cin >> rolls;
	int results[21];
	for (int i=0; i<21; i++) {
		results[i] = 0;
	}

	for (int i=0; i < rolls; i++ ) {
		int result = roll() + roll() + roll() + roll();
		results[result - 4]++;
	}
	
	printHistogram(results);

	return 0;

}
