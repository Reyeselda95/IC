#include <iostream>
#include <algorithm>
using namespace std;


float c(float white, int color) {
	return (white - color/255.0f)/white;
}

int main()
{
  // Enter your code here
	int r, g, b;
	cout << "Enter Red: ";
	cin >> r;
	cout << "Enter Green: ";
	cin >> g;
	cout << "Enter Blue: ";
	cin >> b;

	float white = max(max(r, g), b) / 255.0f;

	cout << "cyan: " << c(white, r) << endl;
	cout << "magenta: " << c(white, g) << endl;
	cout << "yellow: " << c(white, b) << endl;
	cout << "black: " << 1 - white << endl;


  return 0;
}
