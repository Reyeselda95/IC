#include <iostream>
#include "bigint.h"
// using namespace std;
vector<int> addTogether(vector<int>smaller, vector<int>bigger);
BigInt::BigInt(string s) {
  for (int i = 0; i < s.length(); i++) {
    values.push_back( (int)s[s.length() - i - 1] - (int)'0' );
  }
}

void BigInt::println() {
  for (int i = values.size()-1; i >= 0; i--)
    cout << values[i];
  cout << endl;
}

void BigInt::add(BigInt b) {

  if (values.size() > b.values.size()) {
    values = addTogether(b.values, values);
  } else {
    values = addTogether(values, b.values);
  }
}

vector<int> addTogether(vector<int>smaller, vector<int>bigger) {
  vector<int> summation = bigger;
  int carry = 0;

  for (int i = 0; i < smaller.size(); i++) {
    int sum = (smaller[i] + bigger[i] + carry);
    carry = sum / 10;
    summation[i] = (sum % 10);

    if (i == smaller.size() - 1)
      if (carry != 0)
        summation.push_back(carry);

  }
  return summation;
}
