#include <iostream>
#include "bigint.h"

int main() {

  BigInt x("1");
  cout << x.values;

}
