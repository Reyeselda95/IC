#ifndef USER_H
#define USER_H

#include <string>
#include <vector>
using namespace std;
class User {
 public:
   string username;
   int id, birth_year, zip;
   vector<int> friends;

   User() {

   }

   User(char *name, int b, int zip_code) {
     username = name;
     birth_year = b;
     zip = zip_code;
   }

   void add_friend(int);
   void delete_friend(int);

 private:

};


#endif
