#include <stdio.h>

int tasty(int *x) {
	printf("Int tasty");
}

int tasty(char *x) {
	printf(x);
}

int main() {
	int *test;
	*test = 1;
	char *test2 = "hey";
	tasty(test);
	tasty(test2);

//	int tasty();
//	void tasty();
	return 0;

}
