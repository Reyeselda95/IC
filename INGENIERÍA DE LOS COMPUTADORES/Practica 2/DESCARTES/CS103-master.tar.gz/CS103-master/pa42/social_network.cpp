#include <iostream>
#include "network.h"
#include "user.h"

using namespace std;

int main(int argc, char *argv[])
{


  if (argc != 2) {
    cout << "Usage ./social_network filename" << endl;
    return -1;
  }

  char *filename = argv[1];

  Network network = Network();
  network.read_friends(filename);

  while (true) {

    cout << ">";

    int c;
    cin >> c;

    if (c == 1) {
      // Add user
      char *name = "";
      int born, zip;
      cin >> name >> born >> zip;
      network.add_user(name, born, zip);
    } else if (c == 2) {
      // Add friend connection
      string first, last, first1, last1;

      cin >> first >> last >> first1 >> last1;

      int user1 = network.get_id(first.append(" ").append(last).c_str());
      int user2 = network.get_id(first1.append(" ").append(last1).c_str());
      network.add_connection(user1, user2);
    } else if (c == 3) {
      // Remove friend connection
      string first, last, first1, last1;

      cin >> first >> last >> first1 >> last1;

      int user1 = network.get_id(first.append(" ").append(last).c_str());
      int user2 = network.get_id(first1.append(" ").append(last1).c_str());
      network.remove_connection(user1, user2);

    } else if (c == 4) {
      // Print users
      cout << "ID     Name                Year                         Zip" << endl;
      cout << "===========================================================" << endl;

      for (int i = 0; i < network.users.size(); i++) {
        User u = network.users[i];
        cout << u.id << "." << "      ";
        cout << u.username << "       ";
        cout << u.birth_year << "           " << u.zip << endl;
      }
    } else if (c == 5) {
      // List friends
      char *name = "";
      cin >> name;
      int id = network.get_id(name);
      User u = network.get_user(id);
      cout << "ID     Name                Year                         Zip" << endl;
      cout << "===========================================================" << endl;
      for( int i = 0; i < u.friends.size(); i++) {
        User x = network.get_user(u.friends[i]);
        cout << x.id << "." << "      ";
        cout << x.username << "       ";
        cout << x.birth_year << "           " << x.zip << endl;

      }
    } else if (c == 6) {
      // Write to file
    } else if (c == 7) {
      return -1;
    }

  }

  return 0;
}
