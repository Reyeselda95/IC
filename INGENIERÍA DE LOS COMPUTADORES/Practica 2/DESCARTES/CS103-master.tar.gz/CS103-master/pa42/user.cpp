#import "user.h"

void User::add_friend(int id) {
  friends.push_back(id);
}

void User::delete_friend(int id) {
  for (int i = 0; i< friends.size(); i++)
    if (friends[i] == id)
      friends.erase(friends.begin() + i);
}
