#ifndef NETWORK_H
#define NETWORK_H

#include "user.h"
#include <vector>

using namespace std;

class Network {
 public:
   int usersn;
   vector<User> users;
   int read_friends(char *filename);
   int write_friends(char *filename);
   int add_user(char *name, int birth_year, int zip_code);
   int add_connection(int id1, int id2);
   int remove_connection(int id1, int id2);
   int get_id(const char *);
   User get_user(int);

    Network() {

    }

 private:

};


#endif
