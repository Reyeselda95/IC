#include <iostream>
#include <string>
#include "network.h"
#include <fstream>
#include <sstream>
using namespace std;

int Network::read_friends(char *filename) {

  ifstream usersfile (filename);

  if (usersfile.is_open()) {

    // Get first line from file and parse into usersn
    string buffer;
    getline(usersfile, buffer);
    usersn = atoi(buffer.c_str());

    while (!usersfile.eof()) {
      cout << buffer << endl;
      User new_user = User();
      getline(usersfile, buffer);
      new_user.id = atoi(buffer.c_str());

      getline(usersfile, new_user.username);

      getline(usersfile, buffer);
      new_user.birth_year = atoi(buffer.c_str());

      getline(usersfile, buffer);
      new_user.zip = atoi(buffer.c_str());

      int i = 0;
      string id;
      getline(usersfile, buffer);
      for (stringstream s(buffer); s >> id;) {
        new_user.friends.push_back(atoi(id.c_str()));
      }

      // c
      this->users.push_back(new_user);
    }

  }

  return 1;

}

int Network::write_friends(char *filename) {

  ofstream usersfile (filename);

  if (usersfile.is_open()) {

    while (!usersfile.eof()) {

      usersfile << this->users.size() << endl;

      for (int i = 0; i < this->users.size(); i++) {

        usersfile << this->users[i].id << endl;
        usersfile << "\t" << this->users[i].username << endl;
        usersfile << "\t" << this->users[i].birth_year << endl;
        usersfile << "\t" << this->users[i].zip << endl;

        usersfile << "\t";
        for (int j = 0; j < this->users[i].friends.size(); j++) {
          usersfile << this->users[i].friends[j] << " ";
        }
        usersfile << endl;

      }

    }

  } else {
    return -1;
  }

  return 0;

}

int Network::add_user(char *name, int birth_year, int zip_code) {

  User user = User(name, birth_year, zip_code);
  users.push_back(user);
  return 0;
}

int Network::add_connection(int id1, int id2) {
  get_user(id1).add_friend(id2);
  get_user(id2).add_friend(id1);
  return 0;
}

int Network::remove_connection(int id1, int id2) {

  get_user(id1).delete_friend(id2);

  get_user(id2).delete_friend(id1);
  return 0;
}

int Network::get_id(const char *username) {
  for (int i = 0; i < this->users.size(); i++) {

    if ( strcmp(username, this->users[i].username.c_str()) == 0) {
      return users[i].id;
    }

  }

  return -1;

}

User Network::get_user(int id) {
  for (int i = 0; i < this->users.size(); i++)
    if (this->users[i].id == id)
      return this->users[i];
}
