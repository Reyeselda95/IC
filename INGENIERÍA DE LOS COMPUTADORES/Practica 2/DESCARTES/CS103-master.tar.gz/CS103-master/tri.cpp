#include <iostream>
#include <cmath>

using namespace std;

int main() {
	
	int angle;
	cout << "Enter a value for the top angle: " << endl;
	cin >> angle;

	if (angle < 15)
		angle = 15;
	if (angle > 75)
		angle = 75;

	for (int i =0; i<30; i++) {
		float length = tan(angle * 3.14f/180) * i;

		if (length > 20 && length <= 30)
			length = 20;
		for (int j=0; j<length; j++) {
			cout << "*";
		}
		cout << endl;
	}
		

}
