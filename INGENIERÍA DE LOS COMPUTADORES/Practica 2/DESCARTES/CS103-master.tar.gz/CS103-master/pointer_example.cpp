#include <iostream>
using namespace std;

void change_x(int*x) {
	*x = 150;
}

int change_copy_of_x(int copy_of_x) {
	copy_of_x = 150;
	return copy_of_x;
}

int main() {

	int modifiable, not_modifiable;
	modifiable = 100;
	not_modifiable = 200;

	change_x( &modifiable );

	change_copy_of_x(not_modifiable);

	cout << "Modified variable: " << modifiable << endl;
	cout << "Not modified variable: " << not_modifiable << endl;
	cout << "Modified locally: " << change_copy_of_x(not_modifiable) << endl;
}
