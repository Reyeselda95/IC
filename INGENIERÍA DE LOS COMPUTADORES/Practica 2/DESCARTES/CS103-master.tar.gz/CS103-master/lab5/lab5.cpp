#include <iostream>
#include <cmath>
#include "bmplib.h"

using namespace std;

unsigned char image[SIZE][SIZE];

// Prototypes
void draw_rectangle(int top, int left, int height, int width);
void draw_ellipse(int cy, int cx, int height, int width);


int main()
{

  // initialize the image to all white pixels
  for(int i=0; i < SIZE; i++){
    for(int j=0; j < SIZE; j++){
      image[i][j] = 255;
    }
  }


  // Main program loop here

	cout << "To draw a rectangle, enter: 0 top left height width" << endl <<
					"To draw an ellipse, enter: 1 cy cx height width" << endl <<
					"To save your drawing as \"output.bmp\" and quit, enter: 2" << endl << endl;

	while (true) {
		cout << "DrawBMP >>  ";
		int args[5];
		cin >> args[0];
		if (args[0] == 2) {
		  // Write the resulting image to the .bmp file
		  writeGSBMP("output.bmp", image);
			return 0;
		} else if (args[0] == 1 || args[0] == 0) {
			
			for (int i = 0; i < 4; i++) 
				cin >> args[i+1];

			if (args[0] == 0)
				draw_rectangle(args[1], args[2], args[3], args[4]);
			if (args[0] == 1)
				draw_ellipse(args[1], args[2], args[3], args[4]);
		}
	}

  return 0;
}

void draw_rectangle(int top, int left, int height, int width)
{
	for (int i = max(0, min(top, 255)); i <= max(0, min(top + height, 255)); i++) {
		
		image[i][max(0, min(255, left))] = 0;
		image[i][max(0, min(left + width, 255))] = 0;
	}	
	for (int i = max(0, min(left, 255)); i <= max(0, min(left + width, 255)); i++) {
		image[max(0, min(top, 255))][i] = 0;
		image[max(0, min(top + height, 255))][i] = 0;
	}
}

void draw_ellipse(int cy, int cx, int height, int width)
{
  for(double theta=0.0; theta < 2*M_PI; theta += .01){
    int x = (width/2)*cos(theta);
    int y = (height/2)*sin(theta);
    x += cx;
    y += cy;
    image[max(0, min(y, 255))][max(0, min(x, 255))] = 0;
  }
}
