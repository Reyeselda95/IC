#include <iostream>

using namespace std;

int main() {

	cout << "Enter a number: ";
	int num;
	cin >> num;

	int i = 1;

	while (num / i > 0) {
		cout << i << "'s digit is " << (num / i) % 10 << endl;
		i *= 10;
	}

}
