CSCI Programming Assignment 1, Going Broke, Fall 2014

Name: Brian Wheeler

Email Address: bawheele@usc.edu

Section: 29920

ID: 1533499739

NOTE: You can delete the questions, we only need your responses.

=============================== Prelab =======================================

1. How will you generate a coin-toss outcome for each player? (i.e. map the 
random number returned by rand() to a Heads/Tails outcome)

Response 1:

Generate a random number between 0 and 1 and use inequality operator to determine outcome represented as either true or false (since we don’t care about heads or tails we can use either inequality operator, but if the game depended on heads or tails we would have to pick whichever inequality operator fit our needs and then map true and false to heads/tails values, but thankfully this assignment is simpler than that :)

2. Based on the coin-toss outcome for each player, what cases do you need to 
check for to decide how to do the coin bookkeeping? What logical 
connectors do you use?

Response 2:

Need to check equality of all three coin flips. If inequality exists, increment the winning player’s array index by two and decrease the other indexes by 1


3. Is the number of iterations/turns that a single game requires known a priori
(which simply means "beforehand" but is used quite often in computer 
science speak). What kind of loop should then be used and what is its 
terminating condition?

Response 3:

No, the average number of iterations is what we are trying to find out. Loop while all player’s score is greater than 0 (no one has gone broke yet). The while loop works nicely because we can modify conditions inside the loop without having to specify a constant modifying instruction, such as i++.

4. What data needs to be maintained for the total simulation (i.e. across 
several games)? What type?

Response 4:

Integer representing number of total moves made. Average will be total moves across all games / number of simulations.

5. Is the number of iterations for the total simulations known before entering 
the loop? What kind of loop should then be used?

Response 5:

Because the number of simulations is constant in the program a `for` loop should be used, where we can set initial condition, stop condition, and modifier.

6. Also, consider the case that somehow the players all use unfair (possibly 
weighted) coins that come up as heads with probability, p. We will start by 
simulating fair coins where p=0.5. Assuming that for fair coins (p=0.5) we 
calculate x number of flips per game. How will the number of flips per game 
change if p = 0.1? Will it stay the same or go up or down and how 
dramatically? Think about this scenario and write a sentence of two
explaining your prediction and your reasoning before starting to code your 
solution.

Response 6:

The minimum average number of flips will be reflected by the most fair coin (p=.5), because the probability of all coins being the same will be the least at this point (⅜), whereas elsewhere it could be 27/64 such as in the case of p=.25, or as much as 100% in the case of p=0 or p=1.

====================== Data from Procedure Step 6 ==========================

Coins | Probability | Simulations | Result
-----------------------------------------------------
    3    |        0.5      |       5        |    4.2     
-----------------------------------------------------------
    3    |        0.5      |       10        |    5.3     
-----------------------------------------------------------
    3    |        0.5      |       50        |    4.66
-----------------------------------------------------
    3    |        0.5      |       100        |    5.08     
-----------------------------------------------------------
    3    |        0.5      |       1000        |    5.284     
-----------------------------------------------------------
    3    |        0.5      |       10000        |    5.1386     
-----------------------------------------------------------
    3    |        0.5      |       100000        |    5.15036     
-----------------------------------------------------------
 
====================== Data from Procedure Step 7 ==========================


    3    |        0.1      |       10000        |    14.2267     
-----------------------------------------------------------
    3    |        0.2      |       10000        |    8.0347     
-----------------------------------------------------------
    3    |        0.3      |       10000        |    6.1441     
-----------------------------------------------------------
    3    |        0.4      |       10000        |    5.3338     
-----------------------------------------------------------
    3    |        0.5      |       10000        |    5.1029     
-----------------------------------------------------------
    3    |        0.6      |       10000        |    5.3232     
-----------------------------------------------------------
    3    |        0.7      |       10000        |    6.0962     
-----------------------------------------------------------
    3    |        0.8      |       10000        |    8.0426     
-----------------------------------------------------------
    3    |        0.9      |       10000        |    14.3176     
-----------------------------------------------------------

================================== Review ===================================

1. For your first data set, what, in your opinion, is the "point of 
diminshing returns" where the extra time waiting for the simulation 
is not worth the increased accuracy?

Response 1:

Judging by the trials it appears that the returns begin to diminish at around 10,000 trials, possibly more, possibly less. If I was tasked with developing a system for computing probabilities such as this I would weigh the need for accuracy against the need for computational efficiency and make my decision on the point of diminishing return based on those criteria.

2. Examine your results as p varies in your second data set.
Do these results match your expectations of the behavior of the average 
number of flips as p approaches 0 or 1?

Response 2:

As expected, the number of turns became greater as the coin became less and less fair, represented by its deviation from 0.5.

3. When we examined the effects of varying p, why did we start at 0.1 and end 
at 0.9 rather than starting at 0.0 and ending at 1.0?

Response 3:

Inputting probabilities p=0 or p=1 would cause the program to enter into an infinite loop (the way I wrote it) because the coin flips would always be equal. 

================================ Remarks ====================================

Filling in anything here is OPTIONAL.

Approximately how long did you spend on this assignment?

2 hours

Were there any specific problems you encountered? This is especially useful to
know if you turned it in incomplete.

I had to make use of stack overflow to figure out how to create a weighted random boolean expression (for example p=0.7 so the bool is true 70% of the time)

Do you have any other remarks?

:
