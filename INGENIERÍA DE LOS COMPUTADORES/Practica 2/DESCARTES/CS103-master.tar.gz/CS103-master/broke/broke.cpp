#include <iostream>
#include <ctime>
#include <cmath>
#include <unistd.h>
#include <cstdlib>
#include <stdio.h>

using namespace std;

int main(int argc, char **argv) {

	int init_coins;
	float prob;
	int sims;
	srand(time(NULL));

	if (argc != 4) {
		cout << "Enter the number of initial coins: ";
		cin >> init_coins;
		
		cout << endl << "Enter the probability of heads from 0(inclusive) - 1(exclusive): ";
		cin >> prob;
	
		cout << "Enter the number of simulations: ";
		cin >> sims;
	} else { 
		sscanf(argv[1], "%d", &init_coins);
		sscanf(argv[2], "%f", &prob);

		if (prob < 0 || prob >= 1) {
			cout << "Probability must be between 0 and 1(exclusive)" << endl;
			return 1;
		}

		sscanf(argv[3], "%d", &sims);
	}

	int moves = 0;

	
	int players[3];
	bool flips[3];
	
	for (int i = 0; i < sims; i++) {
		
		for (int i = 0; i < 3; i++)
			players[i] = init_coins;

		while ( players[0] > 0 && players[1] > 0 && players[2] > 0 ) {
			
			for (int i = 0; i < 3; i++ )
				flips[i] = prob < (rand() *1.0f / RAND_MAX);

			moves++;

			if ( flips[0] != flips[1] || flips[1] != flips[2] ) {

				for (int i = 0; i < 3; i++) {
					bool unique = true;
		
					for (int j = 0; j < 3; j++) {
						if (flips[i] == flips[j] && j != i)
							unique = false;
					}
	
					(unique) ? (players[i] += 2) : (players[i]--) ;
				}				

			}		

		}
	
	}
	
	float average = moves / (float)sims;
//	cout << "    " << init_coins << "    |        " << prob << "      |       " << sims << "        |    " << average << "     " << endl;
//	cout <<  "-----------------------------------------------------------" << endl;
			
	cout << average << endl;

	return 0;
}
