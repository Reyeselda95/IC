#import <iostream>
#import "turtle.h"

using namespace std;

int main() {

  Turtle t1(10, 20);
  Turtle t2(10, 50);
  Turtle t3()
}
