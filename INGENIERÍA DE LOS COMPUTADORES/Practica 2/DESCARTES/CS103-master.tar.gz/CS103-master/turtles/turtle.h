#import <iostream>
#import "bmplib3.h"
using namespace std;

class Turtle {
  private:
    double row, col, orientation;
    color line;
    bool draw;
  public:
    Turtle (double, double, double);

    void move(double dist);

    void turn(double deg);

    void setColor(color c);

    void off();
    void on();
};
