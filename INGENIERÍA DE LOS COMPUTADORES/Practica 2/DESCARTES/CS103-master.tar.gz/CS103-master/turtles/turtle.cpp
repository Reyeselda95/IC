#import "turtle.h"
#import <cmath>

Turtle::Turtle (double r, double c, double o) {
  row = r;
  col = c;
  orientation = o;
  draw = true;
  line = gray;
}


void Turtle::move(double dist)
{

  int r1 = row, c1 = col;
  row += ( cos(orientation * 3.14 / 180) * dist );
  col += (sin(orientation * 3.14 / 180) * dist  );

  if (draw)
    std_draw_line(line, r1, c1, max((double)0, min((double)SIZE, row)), max((double)0, min((double)SIZE, col)) );
}

void Turtle::turn (double deg) {
  orientation += (deg);
  orientation = (int)orientation % 360;
}

void Turtle::setColor(color c) {
  line = c;
}

void Turtle::off() {
  draw = false;
}

void Turtle::on() {
  draw = true;
}
